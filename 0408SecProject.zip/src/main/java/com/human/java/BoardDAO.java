package com.human.java;

import java.util.HashMap;
import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class BoardDAO {
	
	private static final Logger logger = LoggerFactory.getLogger(BoardDAO.class);

	@Autowired
	private SqlSessionTemplate mybatis;

	public List<BoardVO> getBoardList() {
		
		logger.info(">> DAO : getBoardList.do 진입");
		
		return mybatis.selectList("boardMapper.getBoardList");
		
	}

	public void boardSave(BoardVO vo) {

		logger.info(">> DAO : boardSave.do 진입");
		
		mybatis.insert("boardMapper.boardSave",vo);
		
	}

	public BoardVO getboard(BoardVO vo) {
		
		logger.info(">> DAO : getBoard.do 진입");
		
		return mybatis.selectOne("boardMapper.getBoard", vo);
		
	}

	public void replyInsert(BoardVO vo) {

		mybatis.insert("boardMapper.boardSave", vo);
		
	}

	public int getGroupId() {
		
		return mybatis.selectOne("boardMapper.getGroupId");
	}

	
	public String selectLastSeqNum(String maxSeqNum, String minSeqNum) {
		HashMap map = new HashMap();
		map.put("maxSeqNum", maxSeqNum);
		map.put("minSeqNum", minSeqNum);
		return mybatis.selectOne("boardMapper.selectLastSeqNum", map);
		// return mybatis.selectOne("boardMapper.selectLastSeqNum", maxSeqNum, minSeqNum);은 에러이므로 map에 담아서 보내기
	}
	

}