package com.human.java;

import java.text.DecimalFormat;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BoardService {
	
	private static final Logger logger = LoggerFactory.getLogger(BoardService.class);
	
	@Autowired
	BoardDAO boarddao;

	public List<BoardVO> getBoardList() {
		
		logger.info(">> service : getBoardList.do 진입");
		
		
		return boarddao.getBoardList();
		
	}

	public void boardSave(BoardVO vo) {
		logger.info(">> service : boardSave.do 진입");
		System.out.println("pre vo >> " + vo);
		
		// 그룹번호(groupId) 지정 (그룹번호는 DB에서 가져올 수 있다)
		int groupId = boarddao.getGroupId();
		vo.setGroupId(groupId);
		
		// 순서번호(SequenceNo) 지정
		DecimalFormat dformat = new DecimalFormat("0000000000");
		vo.setSequenceNo(dformat.format(groupId)+"999999");
		
		System.out.println("suf vo >> " + vo);
		
		boarddao.boardSave(vo);
		
	}

	public BoardVO getBoard(BoardVO vo) {

		return boarddao.getboard(vo);
		
		
	}

	public void replyInsert(BoardVO vo) {
		logger.info(">> service : replyIndsert.do 진입");
		System.out.println("pre vo > " + vo);
		
		//그룹번호(groupId) 지정(부모의)
		BoardVO parentVO = new BoardVO();
		parentVO.setArticleId(Integer.parseInt(vo.getParentId() ) );
		// 새롭게 VO를 만들어서 articleID를 parentID로 지정 한 후 DB에 보냄
		parentVO = boarddao.getboard(parentVO);
		// DB갔다온 VO
		
		int groupId = parentVO.getGroupId();
		vo.setGroupId(groupId);
		
		// 순서번호(SequenceNo) 지정
		// 부모 레코드 : parentVO(부모의 번호에서 파생되어야 정렬이 가능해지니까)
		// 부모게시글을 체크 : 답글을 쓸 수 있는 깊이 인지(레벨인지) 확인
		
		// 자신의 순서번호를 계산하기
		// 부모순서번호를 기준으로 자식 순서번호로 생성
		String maxSeqNum = parentVO.getSequenceNo(); // 순서번호 최대치가 부모번호(부모번호보다 작아야 하므로)
		String minSeqNum = getSearchMinSeqNum(parentVO); // 순서번호 최소값
		
		System.out.println("최대 : " + maxSeqNum + " / 최소 : " +  minSeqNum);
		// 최대값과 최소값으로 DB에 있는 값을 조회 -> 마지막 자식 순서번호 추출
		
		String lastChildSeq = boarddao.selectLastSeqNum(maxSeqNum, minSeqNum);
		
		System.out.println("DB최소값 : " + lastChildSeq);
		// 답변을 쓸 때 기준이 되는 게시글의 순서번호를 가지고 
		// 그 게시글보다 작은 숫자이면서 다른 그룹의 숫자와는 충돌이 나면 안됨
		
		String sequenceNumber = getSequenceNumber(parentVO, lastChildSeq); 
		
//		DecimalFormat dformat = new DecimalFormat("0000000000");
//		vo.setSequenceNo(dformat.format(groupId)+"999999");
		vo.setSequenceNo(sequenceNumber);
		
		System.out.println("suf vo >> " + vo);
		
//		boarddao.replyInsert(vo);
	}

	private String getSequenceNumber(BoardVO parentVO, String lastChildSeq) {
		return null;
	}

	// 0000000007999999 : 실제 부모데이터 
    // 0000000007000000  값을 만들어야합니다. > 0000000006999999 > 다른그룹의 번호 이므로 만들어지면안됩니다.
    // 0000000007989999 : 실제 부모데이터
    // 0000000007980000 : 이후는 생성되면안됩니다.
    // 다른 그룹번호와 섞이지 않기위해 순서번호의 최소값이 필요합니다.
	private String getSearchMinSeqNum(BoardVO parentVO) {
		String parentSeqNum = parentVO.getSequenceNo();
		DecimalFormat dFormat = new DecimalFormat("0000000000000000");
		
		long parentSeqLongValue = Long.parseLong(parentSeqNum);
		long searchMinLongValue = 0;	// 최소값
		
		// getLevel() : 순서번호의 답글 깊이를 말해주는 함수 
		switch(parentVO.getLevel()) {
		case 0: searchMinLongValue = parentSeqLongValue / 1000000L * 1000000L; break;
		case 1: searchMinLongValue = parentSeqLongValue / 10000L * 10000L; break;
		case 2: searchMinLongValue = parentSeqLongValue / 100L * 100L; break;
		}
		
		return dFormat.format(searchMinLongValue);
		//끝자리가 항상 0으로 완성되어 최소값이 만들어짐 
	}
	
}