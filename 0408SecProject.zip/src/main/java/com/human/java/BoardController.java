package com.human.java;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class BoardController {
	
	
	@Autowired
	BoardService boardservice;
	
	private static final Logger logger = LoggerFactory.getLogger(BoardController.class);
	
	
	@RequestMapping("getBoardList.do")
	public ModelAndView getBoardList() {
		
		logger.info(">> controller : getBoardList.do 진입");
		
		List<BoardVO> bList = boardservice.getBoardList();
		ModelAndView mv = new ModelAndView();
		mv.setViewName("getBoardList");
		mv.addObject("bList", bList);
		
		return mv;
	}
	
	@RequestMapping("boardInsert.do")
	public void boardInsert() {
		
		logger.info(">> controller : boardInsert.do 진입");
		
		// return "boardInsert"; 생략된 상태
	}
	
	@RequestMapping("boardSave.do")
	public String boardSave(BoardVO vo) {
		
		logger.info(">> controller : boardSave.do 진입");
		
		System.out.println(vo);
		
		boardservice.boardSave(vo);
		
		return "redirect:/getBoardList.do";
	}
	
	@RequestMapping("getBoard.do")
	public ModelAndView getBoard(BoardVO vo) {
		
		BoardVO result = boardservice.getBoard(vo);
		ModelAndView mv = new ModelAndView();
		mv.setViewName("getBoard");
		mv.addObject("board", result);
		
		return mv;
	}
	
	// 댓글 페이지 출력
	@RequestMapping("boardReply.do")
	public void boardReply(String parentId, BoardVO vo, Model model) {
		
		logger.info(">> controller : boardReply.do 진입");
		// parentId : 부모의 정보(게시글 번호를 가져와야 하므로)
		System.out.println("parentId >> " + parentId);
		System.out.println("parentID_vo >> " + vo.getParentId());
		
		model.addAttribute("parentId", parentId);
		// 일회성, return해주는 jsp에서만 사용 가능
		
		// return "boardReply"; // 반환타입이 void면 생략 가능
	}
	
	@RequestMapping("boardReplyInsert.do")
	public String boardReplyInsert(BoardVO vo) {
		logger.info(">> contorller : boardReplyInsert.do 진입");
		System.out.println(">> " + vo.toString());
		
		boardservice.replyInsert(vo);
		
		return "redirect:/getBoardList.do";
	}

}